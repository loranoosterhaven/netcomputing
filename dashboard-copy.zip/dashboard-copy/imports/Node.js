export default class Node
{
    constructor(ip) {
        this.ip = ip;
    }

    getIp() {
        return this.ip;
    }
}